package ma.betteryou.betteryoubackend.entity.enums;

public enum ExerciseCategory {
    CARDIO,
    STRENGTH,
    FLEXIBILITY,
    BALANCE
}
