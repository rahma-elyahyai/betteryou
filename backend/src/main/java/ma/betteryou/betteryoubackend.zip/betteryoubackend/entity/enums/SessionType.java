package ma.betteryou.betteryoubackend.entity.enums;

public enum SessionType {
    CARDIO,
    STRENGTH,
    MIXED
}
