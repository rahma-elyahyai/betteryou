package ma.betteryou.betteryoubackend.entity.enums;

public enum FitnessLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}
