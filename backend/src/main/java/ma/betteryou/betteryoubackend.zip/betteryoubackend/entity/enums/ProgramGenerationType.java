package ma.betteryou.betteryoubackend.entity.enums;

public enum ProgramGenerationType {
    AUTO_AI,
    MANUAL
}
