package ma.betteryou.betteryoubackend.entity.enums;

public enum FoodPreferences {
VEGAN,
VEGETARIAN,
KETO,
PALEO,
NONE
}
