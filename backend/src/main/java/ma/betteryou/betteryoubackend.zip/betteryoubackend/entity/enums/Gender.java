package ma.betteryou.betteryoubackend.entity.enums;

public enum Gender {
    MALE,
    FEMALE
}
