package ma.betteryou.betteryoubackend.entity.enums;

public enum SessionStatus {
    PLANNED,
    DONE,
    MISSED
}
