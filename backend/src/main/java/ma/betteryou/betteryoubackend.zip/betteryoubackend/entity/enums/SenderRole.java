package ma.betteryou.betteryoubackend.entity.enums;

public enum SenderRole {
    USER,
    AI
}