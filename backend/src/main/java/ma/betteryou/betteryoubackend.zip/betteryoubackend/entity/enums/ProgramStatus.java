package ma.betteryou.betteryoubackend.entity.enums;

public enum ProgramStatus {
    ONGOING,
    COMPLETED,
    CANCELLED
}
