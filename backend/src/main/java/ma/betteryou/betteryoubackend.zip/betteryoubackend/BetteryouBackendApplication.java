package ma.betteryou.betteryoubackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BetteryouBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(BetteryouBackendApplication.class, args);
    }
}
