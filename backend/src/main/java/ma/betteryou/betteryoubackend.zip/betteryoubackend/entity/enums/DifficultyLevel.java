package ma.betteryou.betteryoubackend.entity.enums;

public enum DifficultyLevel {
    EASY,
    MODERATE,
    HARD
}
