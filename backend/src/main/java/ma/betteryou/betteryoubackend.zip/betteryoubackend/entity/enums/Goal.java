package ma.betteryou.betteryoubackend.entity.enums;

public enum Goal {
    LOSE_WEIGHT,
    MAINTAIN,
    GAIN_MASS
}
